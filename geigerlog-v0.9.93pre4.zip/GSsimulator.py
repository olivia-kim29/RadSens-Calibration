#!/usr/bin/python3
# -*- coding: UTF-8 -*-

"""
GSsimulator.py - Gamma-Scout simulator
use in GeigerLog to simulate responses of a Gamma-Scout device

start as SUDO (!):  sudo ./GSsimulator.py
"""

###############################################################################
#    This file is part of GeigerLog.
#
#    GeigerLog is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    GeigerLog is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with GeigerLog.  If not, see <http://www.gnu.org/licenses/>.
###############################################################################

#cstopb=<bool>  Sets two stop bits, rather than one.

#socat -d -d -d -d tcp-listen:4141,reuseaddr,fork file:/dev/ttyUSB0,nonblock,cs8,b9600,cstopb=0,raw,echo=0
#socat -d -d  pty,b9600,cs8,raw,echo=0    pty,b9600,cs8,raw,echo=0 #cs8 ok, cs7 geht nicht

# check ports with:  stty -F /dev/pts/5

"""
# use sudo to make links
sudo socat -d -d  pty,b9600,raw,echo=0,link=/dev/ttyS90    pty,b9600,raw,echo=0,link=/dev/ttyS91
# but then it needs these commands:
sudo chmod 777 /dev/ttyS91
sudo chmod 777 /dev/ttyS90
# obgleich das schon erfüllt sein sollte:
# lrwxrwxrwx 1 root root       10 Sep  7 11:56 /dev/ttyS90 -> /dev/pts/2
# lrwxrwxrwx 1 root root       10 Sep  7 11:56 /dev/ttyS91 -> /dev/pts/4
"""

__author__          = "ullix"
__copyright__       = "Copyright 2016, 2017, 2018, 2019"
__credits__         = [""]
__license__         = "GPL3"

import sys, os, io, time, datetime
import subprocess
import serial                       # serial port
import serial.tools.list_ports      # allows listing of serial ports

from GSsimData import *

"""
#--------------------------
#using openpty:
# master for pty, slave for tty
m,s = os.openpty()
print (m)
print (s)
# showing terminal name
s1 = os.ttyname(s)
m1 = os.ttyname(m)
print (m1)
print (s1)
#---------------------------
"""

print("\n------------------------ GSsimulator.py -------------------------------")
print("--- Executing subprocess.Popen with socat command: ")
#mypopen = subprocess.Popen(["socat", '-d', '-d', 'pty,b9600,raw,echo=0,link=/dev/ttyS90', 'pty,b9600,raw,echo=0,link=/dev/ttyS91'],
#                           stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
mypopen = subprocess.Popen(["socat", '-d', '-d', 'pty,b9600,raw,echo=0,link=/dev/ttyS90', 'pty,b9600,raw,echo=0,link=/dev/ttyS91'])
print("--- subprocess.Popen: mypopen:           ", mypopen)
print("--- subprocess.Popen: mypopen.args:      ", mypopen.args)
print("--- subprocess.Popen: mypopen.pid:       ", mypopen.pid)
print("--- subprocess.Popen: mypopen.poll:      ", mypopen.poll())
#print("--- subprocess.Popen: wait:              ", mypopen.wait(timeout=4))
#print("--- subprocess.Popen: communicate        ", mypopen.communicate(timeout=2))
#print("--- subprocess.Popen: communicate[0]     ", mypopen.communicate()[0])
#print("--- subprocess.Popen: mypopen.stdin:     ", mypopen.stdin)
#print("--- subprocess.Popen: mypopen.stdout:    ", mypopen.stdout)
#print("--- subprocess.Popen: mypopen.stderr:    ", mypopen.stderr)
#print("--- subprocess.Popen: mypopen.returncode:", mypopen.returncode) # result is None as long as process still running

time.sleep(0.003) # socat needs ~0.001 sec to complete its action; but then keeps running
print("--- Changing permission with os.chmod on: ", '/dev/ttyS90', '/dev/ttyS91', 'to 0o777')
start = time.time()
while True:
    try:
        os.chmod('/dev/ttyS90', 0o777)
        os.chmod('/dev/ttyS91', 0o777)
        break
    except:
        pass
print("--- success after {:0.5f} sec".format(time.time() - start))

v1_result = b'\r\nStandard'
v2_result = b'\r\nVersion 6.10 d93683 4f07 19.08.19 21:20:01'  # from the GSsimData
P_result  = b'\r\nPC-Mode gestartet'
X_result  = b'\r\nPC-Mode beendet'
b_result  = b'\r\n' + (dumpdata.replace("\n", "\r\n")).encode("UTF-8")

start       = time.time()
counter     = 0
NormalMode  = True
#portsim     = "/dev/pts/4"
portsim     = "/dev/ttyS90"
#wser        = serial.serial_for_url(portsim, bytesize=7, parity="E", timeout=0.1)
#wser        = serial.serial_for_url("spy://{}?file=GSsimulator.sim&all&color".format(portsim), baudrate=9600, timeout=0.1)
#wser        = serial.serial_for_url("spy://{}?file=GSsimulator.sim&raw".format(portsim), baudrate=9600, timeout=0.1) # raw gibt Fehler
wser        = serial.serial_for_url("spy://{}?file=GSsimulator.sim".format(portsim), baudrate=9600, timeout=0.1)

#wser        = serial.Serial(port=portsim, baudrate=9600, timeout=0.1)
print("\nwser: ", wser)

while True :
    counter += 1

    rres = wser.readline()
    #print("rres: ", rres)

    print(".", end="")
    if counter % 100 == 0:
        print("{:0.5f}".format((time.time() - start) ))
        start = time.time()

    if rres > b"":
        counter = 0

        if   rres == b"v" and NormalMode:               # b'\r\nStandard'
            tag = v1_result

        elif rres == b"v" and not NormalMode:           # b'\r\nVersion 6.10 d93683 4f07 19.08.19 21:20:01'
            tag = v2_result

        elif rres == b"P":                              # b'\r\nPC-Mode gestartet'
            tag = P_result
            NormalMode = False

        elif rres == b"X" and NormalMode:               # b"\r\n"
            tag = b"\r\n"
            NormalMode = True

        elif rres == b"X" and not NormalMode:           # b'\r\nPC-Mode beendet'
            tag = X_result
            NormalMode = True

        elif rres == b"b" and not NormalMode:           # b'\r\n' + (dumpdata.replace("\n", "\r\n")).encode("UTF-8")
            tag = b_result

        else:                                           # b"\r\nnot recognized"
            tag = b"\r\nnot recognized"

        wser.write(tag)
        print()
        print("Received : {:30s}  on port '{}'".format(str(rres), portsim ))
        print("Answered : {} ".format(tag))


    #time.sleep(0.01) # not needed; the RX timeout of 0.1 sec makes the delay


