#! /usr/bin/python3
# -*- coding: utf-8 -*-

"""
GLpipCheck.py - GeigerLog checks the Pip version status
"""

"""
Using pip as an imported module:  (not recommended, see at bottom of:
https://pip.pypa.io/en/stable/user_guide/

... if you decide that you do want to run pip from within your program. The most
... reliable approach, and the one that is fully supported, is to run pip in a
... subprocess. This is easily done using the standard subprocess module


from pip._internal import main as pipmain

def install(package):
    # test for presence of 'main' (older versions) or use pip._internal.main()
    if hasattr(pip, 'main'):
        pip.main(['install', package])
    else:
        pip._internal.main(['install', package])

pipmain(["list"])
<package name> = e.g. pip, pyserial, ...
pipmain(["show", <package name>])
pipmain(["install","--upgrade", <package name>])
"""

"""
to execute, no output
subprocess.check_call([sys.executable, '-m', 'pip', 'list'])
"""

import sys, subprocess

def pipList():
    res = subprocess.check_output([sys.executable, '-m', 'pip', 'list'])
    return res.decode('UTF-8').strip()


def pipGetVersionFromList(versions):
    """call pip list"""

    global installs

    print("GeigerLog required packages and versions: ")

    reqs = subprocess.check_output([sys.executable, '-m', 'pip', 'list'])
    #print ("reqs:", reqs)

    nreqs = reqs.decode('UTF-8').strip().split("\n")
    #print ("nreqs:", nreqs)

    for nr in nreqs:
        p = nr[0:29].strip()
        v = nr[29:].strip()
        #print(">",p,"<",">",v,"<")

        if p in versions:
            print("         installed:  {:28s} {:20s}".format(p, v))
            installs[p][2] = True
        else:
            pass
            #print("installed but not needed: {:28s} {:20s}".format(p, v))


def pipGetVersionFromOutdatedList(versions):
    """Call pip list --outdated"""
    global installs

    print("Versions with available Upgrade:")

    reqs = subprocess.check_output([sys.executable, '-m', 'pip', 'list', '--outdated'])
    #print ("reqs:", reqs)

    nreqs = reqs.decode('UTF-8').strip().split("\n")
    #print ("nreqs:", nreqs)    # e.g.:  'bottle             0.12.7   0.12.17  wheel',

    counter = 0
    for nr in nreqs:
        #nrl = nr.strip().split(" ")
        #print("nrl: ", nrl)

        p = nr[0:18].strip()
        v = nr[18:27].strip()
        w = nr[26:35].strip()
        #print(">",p,"<",">",v,"<",">",w,"<")

        if p in versions:
            print("         installed:  {:28s} {:20s} {:20s}".format(p, v, w))
            counter += 1
        else:
            pass
            #print("installed but not needed: {:28s} {:20s}".format(p,v))
    if counter == 0: print("         None available")

    counter = 0
    print("\nVersions missing in installation:")
    for pkg in installs:
        #print("         pkg:  {:28s}".format(pkg), pkg)
        if installs[pkg][2] == False:
            print("         missing:  {:28s}".format(pkg))
        #else:
        #    print("         found:    {:28s}".format(pkg))
    if counter == 0: print("         None missing")

###############################################################################

print("\n------------------------ GLpipCheck.py -------------------------------")
print("Executable:     ", sys.executable)
print("Python version: ", sys.version.replace('\n', ""))

# optional for pip:   pip install "SomeProject>=1,<2"
# getting PyAudio
# not present in PyPi files for Python 3.7:  https://pypi.org/project/PyAudio/#files
# alternative using gohlke files
# https://www.lfd.uci.edu/~gohlke/pythonlibs/#pyaudio
#       PyAudio‑0.2.11‑cp37‑cp37m‑win_amd64.whl
# https://www.lfd.uci.edu/~gohlke/pythonlibs/PyAudio‑0.2.11‑cp37‑cp37m‑win_amd64.whl
pyaudiolink = "https://www.lfd.uci.edu/~gohlke/pythonlibs/PyAudio‑0.2.11‑cp37‑cp37m‑win_amd64.whl"
#pyaudiofile = "PyAudio‑0.2.11‑cp37‑cp37m‑win_amd64.whl"

installs = {
            "pip"           : ["latest"     , "pypi", False],
            "setuptools"    : ["latest"     , "pypi", False],
            "matplotlib"    : ["==3.0.3"    , "pypi", False],
            "numpy"         : [">=1.14"     , "pypi", False],
            "scipy"         : ["latest"     , "pypi", False],
            "pyserial"      : ["latest"     , "pypi", False],
            "paho-mqtt"     : ["latest"     , "pypi", False],
            #"PyAudio"       : [">=0.2.11"   , "PyAudio-0.2.11-cp37-cp37m-win_amd64.whl", False],
            "PyAudio"       : [">=0.2.11"   , "pypi", False],
            "PyQt5"         : ["latest"     , "pypi", False],
            "PyQt5-sip"     : ["latest"     , "pypi", False],
            #"pyqt5"         : ["latest"     , "pypi", False],
            #"pyqt5-sip"     : ["latest"     , "pypi", False],
            }

versions =  [
            "pip"       ,
            "setuptools",
            "matplotlib",
            "numpy"     ,
            "scipy"     ,
            "pyserial"  ,
            "paho-mqtt" ,
            "PyAudio"   ,
            #"pyqt5"     ,
            #"pyqt5-sip" ,
            "PyQt5"     ,
            "PyQt5-sip" ,
            ]

line = "#######################################################################"
line2 = "----------------------------------------------------------------------"

#print(pipList())
pipGetVersionFromList(installs)
pipGetVersionFromOutdatedList(installs)

print()

